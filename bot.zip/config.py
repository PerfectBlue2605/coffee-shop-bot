TOKEN = '6640672600:AAEDVVD6FHyvE1Kbwc5G4ujhyt5njdfnkDs' #botfather token

table = 'None'
choosen_milk = 'none'
chat_ids = 265130263